package com.example.proyectotfg;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Registro extends AppCompatActivity {
    private String id;
    private EditText nombre;
    private EditText apellidos;
    private EditText telefono;
    private EditText email;
    private EditText contrasena;
    private CheckBox aceptar;
    private FirebaseAuth auth;
    private RadioButton r1,r2;
    private FirebaseDatabase db;
    private DatabaseReference reference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);
        nombre = findViewById(R.id.nombreRegis);
        apellidos = findViewById(R.id.apellidosRegis);
        telefono = findViewById(R.id.teleRegis);
        email = findViewById(R.id.emailRegis);
        contrasena = findViewById(R.id.contraRegis);
        r1=(RadioButton) findViewById(R.id.Capataz);
        r2=(RadioButton) findViewById(R.id.Costalero);
        aceptar=findViewById(R.id.terminos);
        auth = FirebaseAuth.getInstance();
        db = FirebaseDatabase.getInstance();
        reference=db.getReference();
        random();
    }

    public void random() {
        String banco = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
        String cadena = "";
        for (int x = 0; x < 12; x++) {
            int indiceAleatorio = numeroAleatorioEnRango(0, banco.length() - 1);
            char caracterAleatorio = banco.charAt(indiceAleatorio);
            cadena += caracterAleatorio;
        }
        id=cadena;
    }


    public static int numeroAleatorioEnRango(int minimo, int maximo) {
        return ThreadLocalRandom.current().nextInt(minimo, maximo + 1);
    }
    public void createUser(View view) {
        String name = nombre.getText().toString();
        String lastName = apellidos.getText().toString();
        String phone = telefono.getText().toString();
        String correo = email.getText().toString();
        String contra = contrasena.getText().toString();
        String capataz = r1.getText().toString();
        String cofrade = r2.getText().toString();

        Pattern pattern = Pattern
                .compile("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
                        + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$");
        Matcher valiEmail= pattern.matcher(correo);

        Pattern pattern1 = Pattern.compile("^[6|7]{1}[0-9]{8}$");
        Matcher valiTelefono= pattern1.matcher(phone);

        Pattern pattern2 = Pattern.compile("^[a-z-A-Z]{5,}[0-9]{1,}$");
        Matcher valiContra= pattern2.matcher(contra);

        if (TextUtils.isEmpty(name)) {
            Toast.makeText(Registro.this, "Ingrese un nombre", Toast.LENGTH_SHORT).show();
            nombre.requestFocus();
        } else if (TextUtils.isEmpty(lastName)) {
            Toast.makeText(Registro.this, "Ingrese sus apellidos", Toast.LENGTH_SHORT).show();
            apellidos.requestFocus();
        } else if (TextUtils.isEmpty(phone + "")) {
            Toast.makeText(Registro.this, "Ingrese un teléfono", Toast.LENGTH_SHORT).show();
            telefono.requestFocus();
        }else if (valiTelefono.find()==false){
            Toast.makeText(Registro.this, "Ingrese un número de teléfono válido", Toast.LENGTH_SHORT).show();
            telefono.requestFocus();
        } else if (TextUtils.isEmpty(correo)) {
            Toast.makeText(Registro.this, "Ingrese un correo electrónico", Toast.LENGTH_SHORT).show();
            email.requestFocus();
        }else if(valiEmail.find()==false){
            Toast.makeText(Registro.this, "Debe ingresar un correo electrónico válido", Toast.LENGTH_SHORT).show();
            email.requestFocus();
        }else if (TextUtils.isEmpty(contra)) {
            Toast.makeText(Registro.this, "Ingrese una contraseña", Toast.LENGTH_SHORT).show();
            contrasena.requestFocus();
        }else if (valiContra.find()==false) {
            Toast.makeText(Registro.this, "Ingrese una contraseña de mínimo 5 letras y mínimo un número", Toast.LENGTH_SHORT).show();
            contrasena.requestFocus();
        }else if(!aceptar.isChecked()) {
            Toast.makeText(Registro.this, "Antes de registrarse debe aceptar los terminos", Toast.LENGTH_SHORT).show();
        }else{
            Map<String,Object> user = new HashMap<>();
            if(r1.isChecked()){
                user.put("imagen","https://www.lavozdecordoba.es/wp-content/uploads/2019/04/WhatsApp-Image-2019-04-18-at-01.37.215.jpeg");

            }else{
                user.put("imagen","https://www.ecestaticos.com/imagestatic/clipping/7dd/544/7dd5443c266f4f438ad7b380c138648e/un-costalero-llamado-francisco-rivera.jpg?mtime=1622949653");
            }
            user.put("idUser",id);
            user.put("nombre",name);
            user.put("apellidos",lastName);
            user.put("telefono",phone);
            user.put("email",correo);
            if(r1.isChecked()){
               user.put("tipo",capataz);
            }else if(r2.isChecked()){
                user.put("tipo",cofrade);
            }


            auth.createUserWithEmailAndPassword(correo, contra).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if(task.isSuccessful()){
                        Toast.makeText(Registro.this, "Usuario registrado", Toast.LENGTH_SHORT).show();
                        reference.child("Usuario/"+auth.getCurrentUser().getUid()).setValue(user);
                        startActivity(new Intent(Registro.this, MainActivity.class));
                        nombre.setText("");
                        apellidos.setText("");
                        telefono.setText("");
                        email.setText("");
                        r1.setChecked(false);
                        r1.setChecked(false);
                        aceptar.setChecked(false);
                    }else{
                        Toast.makeText(Registro.this, "Error,hubo un problema", Toast.LENGTH_SHORT).show();
                    }

                }
            });
        }

    }

    public void Descheck(View view){
        if(r1.isChecked()){
            r2.setChecked(false);
        }else if(r2.isChecked()){
            r1.setChecked(false);
        }
    }
}
