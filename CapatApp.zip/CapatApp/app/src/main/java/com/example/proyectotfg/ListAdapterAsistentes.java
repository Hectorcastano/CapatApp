package com.example.proyectotfg;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class ListAdapterAsistentes extends  FirebaseRecyclerAdapter<ListUser, ListAdapterAsistentes.ViewHolder> {
    private ArrayList<ListPaso> list;
    /**
     /**
     * Initialize a {@link RecyclerView.Adapter} that listens to a Firebase query. See
     * {@link FirebaseRecyclerOptions} for configuration options.
     *
     * @param options
     */
    public ListAdapterAsistentes(@NonNull FirebaseRecyclerOptions<ListUser> options) {
        super(options);
    }


    @Override
    protected void onBindViewHolder(@NonNull final ViewHolder holder, int position, @NonNull final ListUser model){
        Glide.with(holder.img.getContext()).load("https://www.ecestaticos.com/imagestatic/clipping/7dd/544/7dd5443c266f4f438ad7b380c138648e/un-costalero-llamado-francisco-rivera.jpg?mtime=1622949653").into(holder.img);
        holder.nombre.setText(model.getNombre());
        holder.apellidos.setText(model.getApellidos());
        holder.altura.setText(model.getAltura());


    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.list_element_asistentes,parent,false);
        return new ViewHolder(view);
    }



    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView nombre,apellidos,altura;
        ImageView img;

        public ViewHolder(View itemView) {
            super(itemView);
            img=itemView.findViewById(R.id.imagenView);
            altura=itemView.findViewById(R.id.alturaAsistentes);
            nombre=itemView.findViewById(R.id.nombre);
            apellidos=itemView.findViewById(R.id.apellidos);
        }

    }

}

