package com.example.proyectotfg;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;

import java.io.Serializable;
import java.util.HashMap;

public class ListAdapterPasoCos extends FirebaseRecyclerAdapter<ListPaso, ListAdapterPasoCos.ViewHolder> {
    public String pasoActual;
    /**
     * Initialize a {@link RecyclerView.Adapter} that listens to a Firebase query. See
     * {@link FirebaseRecyclerOptions} for configuration options.
     *
     * @param options
     */
    public ListAdapterPasoCos(@NonNull FirebaseRecyclerOptions<ListPaso> options) {
        super(options);
    }


    /**
     * Initialize a {@link RecyclerView.Adapter} that listens to a Firebase query. See
     * {@link FirebaseRecyclerOptions} for configuration options.
     *
     */

    @Override
    protected void onBindViewHolder(@NonNull final ListAdapterPasoCos.ViewHolder holder, int position, @NonNull final ListPaso model) { ;
        Glide.with(holder.image.getContext()).load("https://upload.wikimedia.org/wikipedia/commons/a/a2/Salida_de_Cristo_de_San_Roque_en_su_paso%2C_Sevilla.jpg").into(holder.image);
        holder.name.setText(model.getTitulo());
        holder.date.setText(model.getFecha());
        holder.hour.setText(model.getHora());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               AlertDialog.Builder dialog = new AlertDialog.Builder(view.getContext());
                dialog.setTitle("Introduce un código de invitación");
                final EditText codi = new EditText(view.getContext());
                codi.setInputType(InputType.TYPE_CLASS_TEXT);
                dialog.setView(codi);
                dialog.setPositiveButton("Verificar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    if(codi.getText().toString().equals(model.getCodigo().toString())){


                Intent it = new Intent(holder.itemView.getContext(), InsPaso.class);
                it.putExtra("itemDetail", (Serializable) model);
                holder.itemView.getContext().startActivity(it);
                    }else{
                        Toast.makeText(view.getContext(), "Error, no coincide el código de invitación", Toast.LENGTH_SHORT).show();
                    }
                    }
                });

                dialog.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });

                dialog.show();

            }
        });

            }



    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.list_element_paso,parent,false);
        return new ViewHolder(view);
    }



    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView name,date,hour,invitacion;
        ImageView image;

        public ViewHolder(View itemView) {
            super(itemView);
            image=itemView.findViewById(R.id.imagenView);
            name=itemView.findViewById(R.id.tituloPaso);
            date=itemView.findViewById(R.id.fechaPaso);
            hour = itemView.findViewById(R.id.horaPasoR);
            invitacion = itemView.findViewById(R.id.codigoPaso);
        }

    }
}

