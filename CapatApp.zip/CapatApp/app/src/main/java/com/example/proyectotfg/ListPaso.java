package com.example.proyectotfg;

import android.widget.ImageView;
import java.io.Serializable;

public class ListPaso implements Serializable{
    private String id;
    private ImageView img;
    private String titulo;
    private String fecha;
    private String hora;
    private String palos;
    private String tipo;
    private String descripcion;
    private String codigo;
    private int numAsistentes;



    public ListPaso(){

    }


    public ListPaso(ImageView img,String nombre,String fecha,String hora,String nPalos,String descripcion,String codigo,String id,int numAsistentes,String tipo){
        this.id=id;
        this.img=img;
        this.titulo =nombre;
        this.fecha=fecha;
        this.hora=hora;
        this.fecha=fecha;
        this.descripcion=descripcion;
        this.tipo=tipo;
        this.palos=nPalos;
        this.codigo = codigo;
        this.numAsistentes = numAsistentes;

    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public ImageView getImg() {
        return img;
    }

    public void setImg(ImageView img) {
        this.img = img;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String apellidos) {
        this.fecha = apellidos;
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    public String getPalos() {
        return palos;
    }

    public void setPalos(String palos) {
        this.palos = palos;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public int getNumAsistentes() {
        return numAsistentes;
    }

    public void setNumAsistentes(int numAsistentes) {
        this.numAsistentes = numAsistentes;
    }
}

