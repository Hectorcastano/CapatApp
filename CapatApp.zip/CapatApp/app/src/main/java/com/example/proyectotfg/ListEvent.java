package com.example.proyectotfg;

import android.widget.ImageView;

import java.io.Serializable;

public class ListEvent implements Serializable {
    private ImageView img;
    private String titulo;
    private String fecha;
    private String hora;
    private String tipo;
    private String descripcion;
    private String codigo;


    public ListEvent(){

    }


    public ListEvent(ImageView img,String nombre,String fecha,String hora,String tipo,String descripcion,String codigo){
        this.img=img;
        this.titulo =nombre;
        this.fecha=fecha;
        this.hora= hora;
        this.tipo=tipo;
        this.descripcion= descripcion;
        this.codigo = codigo;
    }

    public ImageView getImg() {
        return img;
    }

    public void setImg(ImageView img) {
        this.img = img;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }
}


