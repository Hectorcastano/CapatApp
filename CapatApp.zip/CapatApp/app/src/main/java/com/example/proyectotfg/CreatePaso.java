package com.example.proyectotfg;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.ClipData;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;

public class CreatePaso extends AppCompatActivity {
    private static String codigoFoto;
    private Uri selectedImageUri;
    private String idPaso;
    private ImageView imagen;
    private RadioButton r1,r2;
    private TextView titulo,fecha,descripcion,codigo,hora;
    private DatabaseReference databaseReference;
    private StorageReference storageReference;
    private Spinner numPalo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_paso);
        idPaso = "";
        imagen = findViewById(R.id.imageView5);
        titulo = findViewById(R.id.tituloPaso);
        fecha = findViewById(R.id.fechaPaso);
        descripcion = findViewById(R.id.descripcionPaso);
        numPalo = findViewById(R.id.Spinner2);
        codigo = findViewById(R.id.codigoPaso);
        hora = findViewById(R.id.horaPaso);
        r1=(RadioButton) findViewById(R.id.Varal);
        r2=(RadioButton) findViewById(R.id.Costal);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(CreatePaso.this, R.array.estado_opciones, R.layout.spinner_item_casillas);
        numPalo.setAdapter(adapter);
        databaseReference = FirebaseDatabase.getInstance().getReference();
        pasoRandom();
    }

    private void pasoRandom() {
        String banco = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
        String cadena = "";
        for (int x = 0; x < 12; x++) {
            int indiceAleatorio = numeroAleatorioEnRango(0, banco.length() - 1);
            char caracterAleatorio = banco.charAt(indiceAleatorio);
            cadena += caracterAleatorio;
        }
        idPaso= cadena ;
    }

    public void fecha(View view){
    final Calendar c= Calendar.getInstance();
    int dia = c.get(Calendar.DAY_OF_MONTH);
    int mes = c.get(Calendar.MONTH);
    int ano = c.get(Calendar.YEAR);

        DatePickerDialog date = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                fecha.setText(dayOfMonth+"/"+(month+1)+"/"+year);
            }
        }
        ,dia , mes ,ano);
        date.show();

    }

    public void hora(View view){
        final Calendar c= Calendar.getInstance();
        int horita = c.get(Calendar.HOUR_OF_DAY);
        int minutos = c.get(Calendar.MINUTE);

        TimePickerDialog timer = new TimePickerDialog(this, new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                hora.setText(hourOfDay+":"+minute);
            }
        }
          ,horita, minutos,false);

        timer.show();
    }

    public void random(View view) {
        String banco = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
        String cadena = "";
        for (int x = 0; x < 12; x++) {
            int indiceAleatorio = numeroAleatorioEnRango(0, banco.length() - 1);
            char caracterAleatorio = banco.charAt(indiceAleatorio);
            cadena += caracterAleatorio;
        }
       codigo.setText(cadena);
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setPackage("com.whatsapp");
        intent.putExtra(Intent.EXTRA_TEXT, codigo.getText());

        try {
            startActivity(intent);

        } catch (android.content.ActivityNotFoundException ex) {
            ex.printStackTrace();
            Snackbar.make(view, "El dispositivo no tiene instalado WhatsApp", Snackbar.LENGTH_LONG).show();
        }
    }


    public static int numeroAleatorioEnRango(int minimo, int maximo) {
        return ThreadLocalRandom.current().nextInt(minimo, maximo + 1);
    }




    public void agregarProducto(View view) {
        String tittle = titulo.getText().toString();
        String date = fecha.getText().toString();
        String desc = descripcion.getText().toString();
        String numero=numPalo.getSelectedItem().toString();
        String hour = hora.getText().toString();
        String invitacion = codigo.getText().toString();

        if (TextUtils.isEmpty(tittle)) {
            Toast.makeText(this, "Ingrese un titulo", Toast.LENGTH_SHORT).show();
            titulo.requestFocus();
        } else if (TextUtils.isEmpty(date)) {
            Toast.makeText(this, "Ingrese una fecha", Toast.LENGTH_SHORT).show();
            fecha.requestFocus();
        }else if (TextUtils.isEmpty(hour)) {
            Toast.makeText(this, "Ingrese una hora", Toast.LENGTH_SHORT).show();
            hora.requestFocus();
        }else if (TextUtils.isEmpty(desc )) {
            Toast.makeText(this, "Ingrese una descripción", Toast.LENGTH_SHORT).show();
            descripcion.requestFocus();
        }else if (TextUtils.isEmpty(invitacion )) {
            Toast.makeText(this, "Debe generar un código de invitación ", Toast.LENGTH_SHORT).show();
            codigo.requestFocus();
        }else {
            Map<String,Object> datos=new HashMap<>();
            datos.put("imagen","https://upload.wikimedia.org/wikipedia/commons/a/a2/Salida_de_Cristo_de_San_Roque_en_su_paso%2C_Sevilla.jpg");
            datos.put("titulo",tittle);
            datos.put("fecha",date);
            datos.put("hora",hour);
            datos.put("descripcion",desc);
            if(r1.isChecked()){
                datos.put("tipo","Varal");
            }else{
                datos.put("tipo","Costal");
            }
            datos.put("palos",numero);
            datos.put("codigo",invitacion);
            databaseReference.child("Paso").child(invitacion).setValue(datos);
            Toast.makeText(this,"Paso añadido",Toast.LENGTH_SHORT).show();
            ClipData clip = ClipData.newPlainText("simple text", invitacion);
            AddPaso.adapter.notifyDataSetChanged();
            titulo.setText("");
            fecha.setText("");
            descripcion.setText("");
            hora.setText("");
            codigo.setText("");

            }

        }


    }




