package com.example.proyectotfg;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;


public class UserPaso extends AppCompatActivity {
    private RecyclerView recyclerView;
    private ListAdapterAsistentes adapter;
    private DatabaseReference reference;
    private ListPaso listPaso;
    private String codigoPasoSeleccionado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_paso);
        recyclerView = (RecyclerView) findViewById(R.id.recyclerView7);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        reference = FirebaseDatabase.getInstance().getReference();
        initValues();
        FirebaseRecyclerOptions<ListUser> options =
                new FirebaseRecyclerOptions.Builder<ListUser>()
                        .setQuery(reference.child("AsistentesPasos").orderByChild("codigoPaso").equalTo(codigoPasoSeleccionado), ListUser.class)
                        .build();
        adapter = new ListAdapterAsistentes(options);
        recyclerView.setAdapter(adapter);

    }


    public void initValues() {
        listPaso = (ListPaso) getIntent().getExtras().getSerializable("itemDetail");
        codigoPasoSeleccionado = listPaso.getCodigo();
    }





                @Override
    public void onStart() {
        super.onStart();
        adapter.startListening();
    }

    @Override
    public void onStop() {
        super.onStop();
        adapter.stopListening();
    }


    }



