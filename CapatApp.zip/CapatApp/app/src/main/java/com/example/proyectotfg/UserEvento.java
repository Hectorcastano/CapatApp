package com.example.proyectotfg;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class UserEvento extends AppCompatActivity {
    private RecyclerView recyclerView;
    private ListAdapterAsistentes adapter;
    private DatabaseReference reference;
    private ListEvent listEvent;
    private String codigoEventoSeleccionado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_paso);
        recyclerView = (RecyclerView) findViewById(R.id.recyclerView7);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        reference = FirebaseDatabase.getInstance().getReference();
        initValues();
        FirebaseRecyclerOptions<ListUser> options =
                new FirebaseRecyclerOptions.Builder<ListUser>()
                        .setQuery(reference.child("AsistentesEvento").orderByChild("codigoEvento").equalTo(codigoEventoSeleccionado), ListUser.class)
                        .build();
        adapter = new ListAdapterAsistentes(options);
        recyclerView.setAdapter(adapter);


    }

    public void initValues() {
        listEvent = (ListEvent) getIntent().getExtras().getSerializable("itemDetail");
        codigoEventoSeleccionado = listEvent.getCodigo();

    }


    @Override
    public void onStart() {
        super.onStart();
        adapter.startListening();
    }

    @Override
    public void onStop() {
        super.onStop();
        adapter.stopListening();
    }


}