package com.example.proyectotfg;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;

public class Contrasena extends AppCompatActivity {
    private Button boton;
    private EditText recuEmail;
    private String correoElectronico;
    private FirebaseAuth contraAuth;
    private ProgressDialog dialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contrasena);

        dialog=new ProgressDialog(this);
        contraAuth= FirebaseAuth.getInstance();
        recuEmail=(EditText) findViewById(R.id.correoRecu);
        boton=(Button) findViewById(R.id.enviar);

        boton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                correoElectronico=recuEmail.getText().toString();

                if(!correoElectronico.isEmpty()){
                    dialog.setMessage("Espera un momento...");
                    dialog.setCanceledOnTouchOutside(false);
                    dialog.show();
                    recuperarContrasena();
                }else{
                    Toast.makeText(Contrasena.this, "Debe introucir un email", Toast.LENGTH_SHORT).show();
                }

            }
        });
    }

    private void recuperarContrasena() {
        contraAuth.setLanguageCode("es");
        contraAuth.sendPasswordResetEmail(correoElectronico).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {

                if(task.isSuccessful()){
                    Toast.makeText(Contrasena.this, "Se ha enviado el correo para restablecer contraseña", Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(Contrasena.this, "ERROR no se pudo enviar el correo de restablecer contaseña", Toast.LENGTH_SHORT).show();
                }

                dialog.dismiss();
            }
        });
    }
    }
