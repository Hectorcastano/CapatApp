package com.example.proyectotfg;

import static android.app.Activity.RESULT_OK;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/**
 * A simple {@link Fragment} subclass.
 * Use the  factory method to
 * create an instance of this fragment.
 */
public class CaptazUser extends Fragment {
    public static ListAdapterUser adapter;
    private String key;
    private TextView pr_name, pr_apellidos, pr_phone, pr_email;
    private FirebaseAuth auth;
    private DatabaseReference reference;
    private DatabaseReference reference2;
    private Button b;
    private ImageView img;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_captaz_user, container, false);
        img = (ImageView)view.findViewById(R.id.imageView4);
        pr_name = (TextView) view.findViewById(R.id.nombreUser);
        pr_apellidos = (TextView) view.findViewById(R.id.ApellidosUser);
        pr_phone = (TextView) view.findViewById(R.id.telefonoUser);
        pr_email = (TextView) view.findViewById(R.id.emailUser);
        b=(Button)view.findViewById(R.id.cerrarSesion);
        auth = FirebaseAuth.getInstance();
        key = auth.getCurrentUser().getUid().toString();
        reference=FirebaseDatabase.getInstance().getReference("Usuario/");
        reference2 = FirebaseDatabase.getInstance().getReference().child("Usuario");
        FirebaseRecyclerOptions<ListUser> options =
                new FirebaseRecyclerOptions.Builder<ListUser>()
                        .setQuery(reference2, ListUser.class)
                        .build();
        adapter = new ListAdapterUser(options);

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                    String imagen= snapshot.child(key+"/imagen").getValue().toString();
                   // System.out.println(imagen);
                    String nombre = snapshot.child(key+"/nombre").getValue().toString();
                    String apellidos = snapshot.child(key+"/apellidos").getValue().toString();
                    String email = snapshot.child(key+"/email").getValue().toString();
                    String telefono = snapshot.child(key+"/telefono").getValue().toString();

                    Glide.with(getActivity())
                        .load(imagen)
                        .into(img);

                        //img.setImageURI(Uri.parse(imagen));
                    pr_name.setText(nombre);
                    pr_apellidos.setText(apellidos);
                    pr_email.setText(email);
                    pr_phone.setText(telefono);

            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });



        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cerrarSesion();
            }
        });



        return view;

    }
    /*
   public void fotoRandom() {
       String banco = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
       String cadena = "";
       for (int x = 0; x < 12; x++) {
           int indiceAleatorio = numeroAleatorioEnRango(0, banco.length() - 1);
           char caracterAleatorio = banco.charAt(indiceAleatorio);
           cadena += caracterAleatorio;
       }
       codigoFoto= cadena ;
   }

   public static int numeroAleatorioEnRango(int minimo, int maximo) {
       return ThreadLocalRandom.current().nextInt(minimo, maximo + 1);
   }


   public void addImage(){
       Intent intent = new Intent();
       intent.setType("image/*");
       intent.setAction(Intent.ACTION_GET_CONTENT);
       startActivityForResult(Intent.createChooser(intent,"Select file to upload "), 10);
   }


   public void onActivityResult(int requestCode, int resultCode, Intent data) {


       super.onActivityResult(requestCode, resultCode, data);
       if (resultCode == RESULT_OK) {
           if (data.getData() != null) {
               selectedImageUri = data.getData();
               img.setImageURI(selectedImageUri);
               uploadImage();

           }

       }

   }

   public void uploadImage(){
       storageReference = FirebaseStorage.getInstance("gs://proyectotfg-bbc04.appspot.com").getReference().child("usuarios/"+codigoFoto+".jpg");
       storageReference.putFile(selectedImageUri);
       reference.child(key+"/imagen").setValue("usuarios/"+codigoFoto+".jpg");
   }



   public void subirDatos() {

       for(ListUser user : users){
           storageReference = FirebaseStorage.getInstance("gs://proyectotfg-bbc04.appspot.com").getReference("vehicles/" + codigoFoto+ ".jpg");
           try {
               File localfile = File.createTempFile("tmp", ".jpg");
               storageReference.getFile(localfile).addOnSuccessListener(new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
                   @Override
                   public void onSuccess(FileDownloadTask.TaskSnapshot taskSnapshot) {
                       Bitmap bitmap = BitmapFactory.decodeFile(localfile.getAbsolutePath());
                       user.setImagen(bitmap);
                   }
               }).addOnFailureListener(new OnFailureListener() {
                   @Override
                   public void onFailure(@NonNull Exception e) {
                       Toast.makeText(getActivity(), "Puede que el servidor haya expirado, dimelo y lo arreglo", Toast.LENGTH_LONG).show();
                   }
               });
           } catch (IOException e) {
               e.printStackTrace();
           }
       }
   }

       DatabaseReference db = FirebaseDatabase.getInstance().getReference("Usuario/" + key);
       db.addValueEventListener(new ValueEventListener() {
           @Override
           public void onDataChange(@NonNull DataSnapshot snapshot) {
               for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                   //ListUser paso = dataSnapshot.getValue(ListUser.class);
                   storageReference = FirebaseStorage.getInstance("gs://proyectotfg-bbc04.appspot.com").getReference("usuarios/" + codigoFoto + ".jpg");
                   try {
                       File localfile = File.createTempFile("tmp", ".jpg");
                       storageReference.getFile(localfile).addOnSuccessListener(new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
                           @Override
                           public void onSuccess(FileDownloadTask.TaskSnapshot taskSnapshot) {
                               Bitmap bitmap = BitmapFactory.decodeFile(localfile.getAbsolutePath());
                               //paso.setImagen(bitmap);
                               System.out.println("aa");
                               adapter.notifyDataSetChanged();
                           }
                       }).addOnFailureListener(new OnFailureListener() {
                           @Override
                           public void onFailure(@NonNull Exception e) {
                               Toast.makeText(getActivity(), "Se ha producido un problema al cargar la imagen", Toast.LENGTH_LONG).show();
                           }
                       });
                   } catch (Exception e) {
                       e.printStackTrace();
                   }
               }


           }

           @Override
           public void onCancelled(@NonNull DatabaseError error) {

           }

       });
   }


*/
            public void cerrarSesion(){
        FirebaseAuth.getInstance().signOut();
         Toast.makeText(getContext(),"Sesión cerrada",Toast.LENGTH_LONG).show();
        startActivity(new Intent(getActivity(),MainActivity.class));
        getActivity().finish();
    }


}