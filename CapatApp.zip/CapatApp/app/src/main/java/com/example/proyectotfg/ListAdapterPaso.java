package com.example.proyectotfg;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;


public class ListAdapterPaso extends FirebaseRecyclerAdapter<ListPaso, ListAdapterPaso.ViewHolder> {
    private ArrayList<ListPaso> list;
    /**
     * Initialize a {@link RecyclerView.Adapter} that listens to a Firebase query. See
     * {@link FirebaseRecyclerOptions} for configuration options.
     *
     * @param options
     */
    public ListAdapterPaso(@NonNull FirebaseRecyclerOptions<ListPaso> options) {
        super(options);
    }

    public void filterList(ArrayList<ListPaso> filter){
        list = filter;
        notifyDataSetChanged();
    }



    /**
     * Initialize a {@link RecyclerView.Adapter} that listens to a Firebase query. See
     * {@link FirebaseRecyclerOptions} for configuration options.
     *
     */

    @Override
    protected void onBindViewHolder(@NonNull final ListAdapterPaso.ViewHolder holder, int position, @NonNull final ListPaso model) { ;
        Glide.with(holder.image.getContext()).load("https://upload.wikimedia.org/wikipedia/commons/a/a2/Salida_de_Cristo_de_San_Roque_en_su_paso%2C_Sevilla.jpg").into(holder.image);
        holder.name.setText(model.getTitulo());
        holder.date.setText(model.getFecha());
        holder.hora.setText(model.getHora());
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it = new Intent(holder.itemView.getContext(), UserPaso.class);
                it.putExtra("itemDetail", (Serializable) model);
                holder.itemView.getContext().startActivity(it);
            }
        });


    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.list_element_paso,parent,false);
        return new ViewHolder(view);
    }

    public interface ListItemClickListener {
    }


    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView name,date,hora;
        ImageView image;

        public ViewHolder(View itemView) {
            super(itemView);
            image=itemView.findViewById(R.id.imagenView);
            name=itemView.findViewById(R.id.tituloPaso);
            date=itemView.findViewById(R.id.fechaPaso);
            hora=itemView.findViewById(R.id.horaPasoR);
        }

    }




}

