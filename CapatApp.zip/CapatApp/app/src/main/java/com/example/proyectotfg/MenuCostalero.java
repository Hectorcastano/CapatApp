package com.example.proyectotfg;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.os.Bundle;
import android.view.MenuItem;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MenuCostalero extends AppCompatActivity {
    BottomNavigationView navigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_costalero);
        navigationView=findViewById(R.id.bottom_navigation);
        getSupportFragmentManager().beginTransaction().replace(R.id.fragmentContainerView2,new AddPasoCos()).commit();
        navigationView.setSelectedItemId(R.id.nav_paso);


        navigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                Fragment fragment=null;
                switch (item.getItemId()){
                    case R.id.nav_paso:
                        fragment=new AddPasoCos();
                        break;
                    case R.id.nav_evt:
                        fragment=new AddEventCos();
                        break;
                    case R.id.nav_user:
                        fragment=new CaptazUser();
                        break;
                }

                getSupportFragmentManager().beginTransaction().replace(R.id.fragmentContainerView2,fragment).commit();
                return true;
            }
        });
    }

}
