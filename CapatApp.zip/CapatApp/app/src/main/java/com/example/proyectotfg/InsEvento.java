package com.example.proyectotfg;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;

public class InsEvento extends AppCompatActivity {
    private String nombre;
    private String apellidos;
    private String idActual;
    private String uid;
    private int altur;
    private String key;
    private ImageView imgDetail;
    private TextView tituloDetail;
    private TextView fechaDetail;
    private TextView horaDetail;
    private TextView descripcionDetail;
    private TextView tipo;
    private ListEvent listElement;
    private FirebaseAuth auth;
    private FirebaseDatabase db;
    private DatabaseReference reference;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ins_evento);
        imgDetail=findViewById(R.id.imageView5);
        tituloDetail=findViewById(R.id.tituloEvento);
        fechaDetail=findViewById(R.id.fechaEvento);
        horaDetail=findViewById(R.id.horaEvent);
        tipo=findViewById(R.id.tipoEventos);
        descripcionDetail=findViewById(R.id.descripcionEvento);
        auth = FirebaseAuth.getInstance();
        uid = auth.getUid().toString();
        db = FirebaseDatabase.getInstance();
        reference=db.getReference();
        initValues();
        getDatos();
    }

    public void getDatos() {
        DatabaseReference db = FirebaseDatabase.getInstance().getReference();
        db.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                //imagen = snapshot.child("Usuario/" + uid + "/imagen").getValue().toString();
                nombre = snapshot.child("Usuario/" + uid + "/nombre").getValue().toString();
                apellidos = snapshot.child("Usuario/" + uid + "/apellidos").getValue().toString();
            }


            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }

        });

    }



    public void initValues(){
        listElement= (ListEvent) getIntent().getExtras().getSerializable("itemDetail");
        idActual= listElement.getCodigo();
        imgDetail.setImageResource(R.drawable.eventos1);
        tituloDetail.setText(listElement.getTitulo());
        fechaDetail.setText(listElement.getFecha());
        horaDetail.setText(listElement.getHora());
        tipo.setText(listElement.getTipo());
        descripcionDetail.setText(listElement.getDescripcion());
    }

    public void asignar(View view) {
        if (tipo.getText().toString().equals("Ensayo")) {
            AlertDialog.Builder alert = new AlertDialog.Builder(InsEvento.this);
            EditText altura = new EditText(view.getContext());
            altura.setInputType(InputType.TYPE_CLASS_NUMBER);
            alert.setView(altura);
            altur = Integer.parseInt(altura.getText().toString());
            alert.setMessage("Si quieres formar parte de esta cuadrilla introduce tu altura en cm")
                    .setCancelable(true)
                    .setPositiveButton("Sí", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            Map<String, Object> asistente = new HashMap<>();
                            asistente.put("img", "https://www.ecestaticos.com/imagestatic/clipping/7dd/544/7dd5443c266f4f438ad7b380c138648e/un-costalero-llamado-francisco-rivera.jpg?mtime=1622949653");
                            asistente.put("nombre", nombre);
                            asistente.put("apellidos", apellidos);
                            asistente.put("altura", altur);
                            asistente.put("codigoEvento", idActual);
                            reference.child("AsistentesEvento").push().setValue(asistente);
                            Toast.makeText(InsEvento.this, "Asistencia confirmada", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(InsEvento.this, MenuCostalero.class));
                            finish();
                        }
                    }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {

                }
            });
            AlertDialog titulo = alert.create();
            titulo.setTitle("Cuadrilla");
            titulo.show();


        } else {

            AlertDialog.Builder alert2 = new AlertDialog.Builder(InsEvento.this);
            alert2.setMessage("¿Desea asistir a este evento?")
                    .setCancelable(true)
                    .setPositiveButton("Sí", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                            Map<String, Object> asistente = new HashMap<>();
                            asistente.put("imagen", "https://www.ecestaticos.com/imagestatic/clipping/7dd/544/7dd5443c266f4f438ad7b380c138648e/un-costalero-llamado-francisco-rivera.jpg?mtime=1622949653");
                            asistente.put("nombre", nombre);
                            asistente.put("apellidos", apellidos);
                            asistente.put("codigoEvento", idActual);
                            reference.child("AsistentesEvento").push().setValue(asistente);
                            Toast.makeText(InsEvento.this, "Asistencia confirmada", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(InsEvento.this, MenuCostalero.class));
                            finish();
                        }


                    })
                    .setNegativeButton("No", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    });
            AlertDialog titulo = alert2.create();
            titulo.setTitle("Asistente");
            titulo.show();

        }
    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
        startActivity(new Intent(InsEvento.this,MenuCostalero.class));
        finish();
    }
}

