package com.example.proyectotfg;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;

public class ListAdapterEventCos extends FirebaseRecyclerAdapter<ListEvent, ListAdapterEventCos.ViewHolder> {
    private ArrayList<ListEvent> list;
    /**
     /**
     * Initialize a {@link RecyclerView.Adapter} that listens to a Firebase query. See
     * {@link FirebaseRecyclerOptions} for configuration options.
     *
     * @param options
     */
    public ListAdapterEventCos(@NonNull FirebaseRecyclerOptions<ListEvent> options) {
        super(options);
    }

    public void filterList(ArrayList<ListEvent> filter){
        list = filter;
        notifyDataSetChanged();
    }


    @Override
    protected void onBindViewHolder(@NonNull final ViewHolder holder, int position, @NonNull final ListEvent model) {
        if (model.getTipo().equals("Ensayo")) {
            Glide.with(holder.image.getContext()).load("https://www.elmira.es/media/elmira/images/2022/01/27/2022012719480077055.jpg").into(holder.image);
        } else if (model.getTipo().equals("Convivencia")) {
            Glide.with(holder.image.getContext()).load("https://www.awali.school/wp-content/uploads/2021/03/Rocas-del-Abra-26-1024x575.jpg").into(holder.image);
        } else if (model.getTipo().equals("Comida")) {
            Glide.with(holder.image.getContext()).load("https://static-sevilla.abc.es/media/gurmesevilla/2012/01/comida-rapida-casera.jpg").into(holder.image);
        } else if (model.getTipo().equals("Ropa")) {
            Glide.with(holder.image.getContext()).load("https://d1bvpoagx8hqbg.cloudfront.net/originals/semana-santa-espana-8a1f1ff020fec25bed1ed87557aa9f57.jpg").into(holder.image);
        } else if (model.getTipo().equals("Culto")) {
            Glide.with(holder.image.getContext()).load("https://www.latercera.com/resizer/yv0U9ssmKWEle3J7-eJbeY1XSU4=/900x600/smart/cloudfront-us-east-1.images.arcpublishing.com/copesa/JBGMFDNYBBHXNAJJCUESDKXEKI.jpg").into(holder.image);
        }
        holder.name.setText(model.getTitulo());
        holder.last_name.setText(model.getFecha());
        holder.hora.setText(model.getHora());
        System.out.println(model.getCodigo());
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder dialog = new AlertDialog.Builder(v.getContext());
                dialog.setTitle("Introduce un código de invitación");
                final EditText codi = new EditText(v.getContext());
                codi.setInputType(InputType.TYPE_CLASS_TEXT);
                dialog.setView(codi);
                dialog.setPositiveButton("Verificar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (codi.getText().toString().equals(model.getCodigo().toString())) {
                            Intent it = new Intent(holder.itemView.getContext(), InsEvento.class);
                            it.putExtra("itemDetail", (Serializable) model);
                            holder.itemView.getContext().startActivity(it);
                        } else {
                            Toast.makeText(v.getContext(), "Error, no coincide el código de invitación", Toast.LENGTH_SHORT).show();
                        }
                    }
                });

                dialog.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });

                dialog.show();
            }
        });

    }




    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.list_element_event,parent,false);
        return new ViewHolder(view);
    }



    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView name,last_name,hora;
        ImageView image;

        public ViewHolder(View itemView) {
            super(itemView);
            image=itemView.findViewById(R.id.imagenView);
            name=itemView.findViewById(R.id.tituloEvento);
            last_name=itemView.findViewById(R.id.fechaEvento);
            hora=itemView.findViewById(R.id.horaEventoR);
        }



    }


}

