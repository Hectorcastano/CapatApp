package com.example.proyectotfg;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;

public class ListAdapterEvent extends FirebaseRecyclerAdapter<ListEvent, ListAdapterEvent.ViewHolder> {
    private ArrayList<ListEvent> list;
    /**
     /**
     * Initialize a {@link RecyclerView.Adapter} that listens to a Firebase query. See
     * {@link FirebaseRecyclerOptions} for configuration options.
     *
     * @param options
     */
    public ListAdapterEvent(@NonNull FirebaseRecyclerOptions<ListEvent> options) {
        super(options);
    }

    public void filterList(ArrayList<ListEvent> filter){
        list = filter;
        notifyDataSetChanged();
    }

    @Override
    protected void onBindViewHolder(@NonNull final ViewHolder holder, int position, @NonNull final ListEvent model) {
        if (model.getTipo().equals("Ensayo")) {
            Glide.with(holder.image.getContext()).load("https://www.elmira.es/media/elmira/images/2022/01/27/2022012719480077055.jpg").into(holder.image);
        }else if(model.getTipo().equals("Convivencia")){
            Glide.with(holder.image.getContext()).load("https://www.awali.school/wp-content/uploads/2021/03/Rocas-del-Abra-26-1024x575.jpg").into(holder.image);
        }else if(model.getTipo().equals("Comida")){
            Glide.with(holder.image.getContext()).load("https://static-sevilla.abc.es/media/gurmesevilla/2012/01/comida-rapida-casera.jpg").into(holder.image);
        }else if(model.getTipo().equals("Ropa")){
            Glide.with(holder.image.getContext()).load("https://d1bvpoagx8hqbg.cloudfront.net/originals/semana-santa-espana-8a1f1ff020fec25bed1ed87557aa9f57.jpg").into(holder.image);
        }else if(model.getTipo().equals("Culto")){
            Glide.with(holder.image.getContext()).load("https://www.latercera.com/resizer/yv0U9ssmKWEle3J7-eJbeY1XSU4=/900x600/smart/cloudfront-us-east-1.images.arcpublishing.com/copesa/JBGMFDNYBBHXNAJJCUESDKXEKI.jpg").into(holder.image);
        }
        holder.name.setText(model.getTitulo());
        holder.last_name.setText(model.getFecha());
        holder.hora.setText(model.getHora());
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it = new Intent(holder.itemView.getContext(), UserEvento.class);
                it.putExtra("itemDetail", (Serializable) model);
                holder.itemView.getContext().startActivity(it);
            }
        });
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.list_element_event,parent,false);
        return new ViewHolder(view);
    }



    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView name,last_name,hora;
        ImageView image;

        public ViewHolder(View itemView) {
            super(itemView);
            image=itemView.findViewById(R.id.imagenView);
            name=itemView.findViewById(R.id.tituloEvento);
            last_name=itemView.findViewById(R.id.fechaEvento);
            hora = itemView.findViewById(R.id.horaEventoR);
        }

    }
}

