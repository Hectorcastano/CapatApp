package com.example.proyectotfg;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.bumptech.glide.annotation.GlideModule;
import com.bumptech.glide.module.AppGlideModule;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.Serializable;
import java.util.ArrayList;

public class ListAdapterUser extends  FirebaseRecyclerAdapter<ListUser, ListAdapterUser.ViewHolder> {
    private ArrayList<ListPaso> list;
    /**
     /**
     * Initialize a {@link RecyclerView.Adapter} that listens to a Firebase query. See
     * {@link FirebaseRecyclerOptions} for configuration options.
     *
     * @param options
     */
    public ListAdapterUser(@NonNull FirebaseRecyclerOptions<ListUser> options) {
        super(options);
    }


    @Override
    protected void onBindViewHolder(@NonNull final ViewHolder holder, int position, @NonNull final ListUser model){
        if (model.getTipo().equals("Capataz")) {
            Glide.with(holder.img.getContext()).load("https://www.lavozdecordoba.es/wp-content/uploads/2019/04/WhatsApp-Image-2019-04-18-at-01.37.215.jpeg").into(holder.img);
        }else{
            Glide.with(holder.img.getContext()).load("https://www.ecestaticos.com/imagestatic/clipping/7dd/544/7dd5443c266f4f438ad7b380c138648e/un-costalero-llamado-francisco-rivera.jpg?mtime=1622949653").into(holder.img);
        }
        holder.nombre.setText(model.getNombre());
        holder.apellidos.setText(model.getApellidos());
        holder.papelera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatabaseReference dbref= FirebaseDatabase.getInstance().getReference().child("Usuario");
                dbref.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        for (DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
                            String key=postSnapshot.getKey();
                                if(postSnapshot.child("idUser").getValue().toString().equals(model.getIdUser())){
                                    postSnapshot.getRef().removeValue();
                                    Toast.makeText(v.getContext(), "Usuario eliminado correctamente", Toast.LENGTH_SHORT).show();
                                    notifyDataSetChanged();
                                }
                            }
                        }


                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
            }
            });

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.list_element_user,parent,false);
        return new ViewHolder(view);
    }



    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView nombre,apellidos;
        ImageView img,papelera;

        public ViewHolder(View itemView) {
            super(itemView);
            img=itemView.findViewById(R.id.imagenView);
            papelera=itemView.findViewById(R.id.borrar);
            nombre=itemView.findViewById(R.id.nombre);
            apellidos=itemView.findViewById(R.id.apellidos);
        }

    }

}

