package com.example.proyectotfg;

import android.graphics.Bitmap;
import android.widget.ImageView;

import java.io.Serializable;

public class ListUser implements Serializable {
    private String imagen;
    private String idUser;
    private ImageView papelera;
    private String nombre;
    private String apellidos;
    private String telefono;
    private String altura;
    private String email;
    private String tipo;


    public ListUser(){

    }


    public ListUser(String img, String nombre, String apellidos, String telefono, String email, String tipo,String altura,ImageView papelera,String id){
     this.imagen= img;
     this.idUser= id;
     this.papelera= papelera;
    this.nombre=nombre;
    this.apellidos=apellidos;
    this.telefono=telefono;
    this.email=email;
    this.tipo=tipo;
    this.altura= altura;
    }

    public String getIdUser() {
        return idUser;
    }

    public void setIdUser(String idUser) {
        this.idUser = idUser;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getImagen() {
        return imagen;
    }

    public ImageView getPapelera() {
        return papelera;
    }

    public void setPapelera(ImageView papelera) {
        this.papelera = papelera;
    }
    public void setImagen(String imagen) {
        this.imagen = imagen;
    }

    public String getAltura() {
        return altura;
    }

    public void setAltura(String altura) {
        this.altura = altura;
    }
}
