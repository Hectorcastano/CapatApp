package com.example.proyectotfg;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;

public class InsPaso extends AppCompatActivity {
    private String nombre;
    private String apellidos;
    private String idActual;
    private String uid;
    private String imagen;
    private ImageView imgDetail;
    private TextView tituloDetail;
    private TextView fechaDetail;
    private TextView horaDetail;
    private TextView descripcionDetail;
    private TextView tipo;
    private TextView numeroPalos;
    private ListPaso listElement;
    private FirebaseAuth auth;
    private FirebaseDatabase db;
    private DatabaseReference reference;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ins_paso);
        imgDetail=findViewById(R.id.imageView5);
        tituloDetail=findViewById(R.id.tituloPaso);
        fechaDetail=findViewById(R.id.fechaPaso);
        horaDetail=findViewById(R.id.horaPaso);
        descripcionDetail=findViewById(R.id.descripcionPaso);
        numeroPalos=findViewById(R.id.numPalos);
        tipo=findViewById(R.id.tipoPaso);
        auth = FirebaseAuth.getInstance();
        uid = auth.getUid().toString();
        db = FirebaseDatabase.getInstance();
        reference=db.getReference();
        initValues();
        getDatos();

    }


    public void getDatos() {
        DatabaseReference db = FirebaseDatabase.getInstance().getReference();
        db.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                //imagen = snapshot.child("Usuario/" + uid + "/imagen").getValue().toString();
                nombre = snapshot.child("Usuario/" + uid + "/nombre").getValue().toString();
               apellidos = snapshot.child("Usuario/" + uid + "/apellidos").getValue().toString();
            }


            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }

        });

    }

    public void initValues(){
        listElement= (ListPaso) getIntent().getExtras().getSerializable("itemDetail");
        idActual= listElement.getCodigo();
        imgDetail.setImageResource(R.drawable.pasito);
        tituloDetail.setText(listElement.getTitulo());
        fechaDetail.setText(listElement.getFecha());
        horaDetail.setText(listElement.getHora());
        descripcionDetail.setText(listElement.getDescripcion());
        tipo.setText(listElement.getTipo());
        numeroPalos.setText(listElement.getPalos());
    }

    public void asignar(View view) {
        AlertDialog.Builder alert = new AlertDialog.Builder(InsPaso.this);
        final EditText altura = new EditText(view.getContext());
        altura.setInputType(InputType.TYPE_CLASS_NUMBER);
        alert.setView(altura);
            alert.setMessage("Si quieres formar parte de esta cuadrilla introduce tu altura en cm")
                    .setCancelable(true)
                    .setPositiveButton("Sí", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            // if(comprobar() == true){
                            Map<String, Object> asistente = new HashMap<>();
                            asistente.put("imagen", imagen);
                            asistente.put("nombre", nombre);
                            asistente.put("apellidos", apellidos);
                            asistente.put("codigoPaso", idActual);
                            asistente.put("altura", altura.getText().toString() + " cm");
                            reference.child("AsistentesPasos").push().setValue(asistente);
                            Toast.makeText(InsPaso.this, "Asistencia confirmada", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(InsPaso.this, MenuCostalero.class));
                            finish();

                        }


                    })
                    .setNegativeButton("No", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    });
            AlertDialog titulo = alert.create();
            titulo.setTitle("Cuadrilla");
            titulo.show();

        }



    @Override
    public void onBackPressed() {
        super.onBackPressed();
        startActivity(new Intent(InsPaso.this,MenuCostalero.class));
        finish();
    }
}