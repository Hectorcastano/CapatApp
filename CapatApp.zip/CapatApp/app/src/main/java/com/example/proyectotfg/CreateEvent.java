package com.example.proyectotfg;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.ClipData;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;

public class CreateEvent extends AppCompatActivity {
    private String idEvento;
    private ImageView imagen;
    private TextView titulo,fecha,descripcion,hora,codigo;
    private DatabaseReference databaseReference;
    private Spinner tipo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_event);
        idEvento = "";
        imagen = findViewById(R.id.imageView5);
        titulo=findViewById(R.id.tituloEvento);
        fecha=findViewById(R.id.fechaEvento);
        hora= findViewById(R.id.horaEvent);
        codigo = findViewById(R.id.codigoEvent);
        descripcion=findViewById(R.id.descripcionPaso);
        tipo=findViewById(R.id.Spinner2);
        ArrayAdapter<CharSequence> adapter=ArrayAdapter.createFromResource(CreateEvent.this,R.array.estado_opciones2,R.layout.spinner_item_casillas);
        tipo.setAdapter(adapter);
        databaseReference= FirebaseDatabase.getInstance().getReference();
        pasoRandom();
    }


    private void pasoRandom() {
        String banco = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
        String cadena = "";
        for (int x = 0; x < 12; x++) {
            int indiceAleatorio = numeroAleatorioEnRango(0, banco.length() - 1);
            char caracterAleatorio = banco.charAt(indiceAleatorio);
            cadena += caracterAleatorio;
        }
        idEvento= cadena ;
    }

    public void fecha(View view){
        final Calendar c= Calendar.getInstance();
        int dia = c.get(Calendar.DAY_OF_MONTH);
        int mes = c.get(Calendar.MONTH);
        int ano = c.get(Calendar.YEAR);

        DatePickerDialog date = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                fecha.setText(dayOfMonth+"/"+(month+1)+"/"+year);
            }
        }
                ,dia , mes ,ano);
        date.show();

    }

    public void hora(View view){
        final Calendar c= Calendar.getInstance();
        int horita = c.get(Calendar.HOUR_OF_DAY);
        int minutos = c.get(Calendar.MINUTE);

        TimePickerDialog timer = new TimePickerDialog(this, new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                hora.setText(hourOfDay+":"+minute);
            }
        }
                ,horita, minutos,false);

        timer.show();
    }

    public void random(View view) {
        String banco = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
        String cadena = "";
        for (int x = 0; x < 12; x++) {
            int indiceAleatorio = numeroAleatorioEnRango(0, banco.length() - 1);
            char caracterAleatorio = banco.charAt(indiceAleatorio);
            cadena += caracterAleatorio;
        }
        codigo.setText(cadena);
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setPackage("com.whatsapp");
        intent.putExtra(Intent.EXTRA_TEXT, codigo.getText());

        try {
            startActivity(intent);

        } catch (android.content.ActivityNotFoundException ex) {
            ex.printStackTrace();
            Snackbar.make(view, "El dispositivo no tiene instalado WhatsApp", Snackbar.LENGTH_LONG).show();
        }
    }


    public static int numeroAleatorioEnRango(int minimo, int maximo) {
        return ThreadLocalRandom.current().nextInt(minimo, maximo + 1);
    }




    public void agregarEvento(View view) {
        String tittle = titulo.getText().toString();
        String date = fecha.getText().toString();
        String hour = hora.getText().toString();
        String desc = descripcion.getText().toString();
        String type=tipo.getSelectedItem().toString();
        String invitacion = codigo.getText().toString();
        if (TextUtils.isEmpty(tittle)) {
            Toast.makeText(this, "Ingrese un titulo", Toast.LENGTH_SHORT).show();
            titulo.requestFocus();
        } else if (TextUtils.isEmpty(date)) {
            Toast.makeText(this, "Ingrese una fecha", Toast.LENGTH_SHORT).show();
            fecha.requestFocus();
        }else if (TextUtils.isEmpty(desc )) {
            Toast.makeText(this, "Ingrese una descripción", Toast.LENGTH_SHORT).show();
            descripcion.requestFocus();
        }else if (TextUtils.isEmpty(invitacion )) {
            Toast.makeText(this, "Debe generar un código de invitación ", Toast.LENGTH_SHORT).show();
            codigo.requestFocus();
        } else {
            Map<String,Object> datos=new HashMap<>();
            if (type.equals("Ensayo")) {
                datos.put("imagen","https://www.elmira.es/media/elmira/images/2022/01/27/2022012719480077055.jpg");
            }else if(type.equals( "Convivencia")){
                datos.put("imagen","https://www.awali.school/wp-content/uploads/2021/03/Rocas-del-Abra-26-1024x575.jpg");
            }else if(type.equals("Comida")){
                datos.put("imagen","https://static-sevilla.abc.es/media/gurmesevilla/2012/01/comida-rapida-casera.jpg");
            }else if(type.equals("Ropa")){
                datos.put("imagen","https://d1bvpoagx8hqbg.cloudfront.net/originals/semana-santa-espana-8a1f1ff020fec25bed1ed87557aa9f57.jpg");
            }else if(type.equals("Culto")){
                datos.put("imagen","https://www.latercera.com/resizer/yv0U9ssmKWEle3J7-eJbeY1XSU4=/900x600/smart/cloudfront-us-east-1.images.arcpublishing.com/copesa/JBGMFDNYBBHXNAJJCUESDKXEKI.jpg");
        }
            datos.put("titulo",tittle);
            datos.put("fecha",date);
            datos.put("hora",hour);
            datos.put("descripcion",desc);
            datos.put("tipo",type);
            datos.put("codigo",invitacion);
            databaseReference.child("Evento").child(invitacion).setValue(datos);
            Toast.makeText(this,"Evento añadido",Toast.LENGTH_SHORT).show();
            ClipData clip = ClipData.newPlainText("simple text", invitacion);
            AddEvent.adapter.notifyDataSetChanged();
            titulo.setText("");
            fecha.setText("");
            descripcion.setText("");
            hora.setText("");
            codigo.setText("");

        }


    }

}