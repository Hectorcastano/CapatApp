package com.example.proyectotfg;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.os.Bundle;
import android.view.MenuItem;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MenuCapataz extends AppCompatActivity {
    BottomNavigationView navigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_capataz);

        navigationView=findViewById(R.id.bottom_navigation);

        getSupportFragmentManager().beginTransaction().replace(R.id.fragmentContainerView2,new AddPaso()).commit();
        navigationView.setSelectedItemId(R.id.nav_paso);


        navigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                Fragment fragment=null;
                switch (item.getItemId()){
                    case R.id.nav_paso:
                        fragment=new AddPaso();
                        break;
                    case R.id.nav_evt:
                    fragment=new AddEvent();
                        break;
                    case R.id.nav_user:
                        fragment=new CaptazUser();
                        break;
                }

                getSupportFragmentManager().beginTransaction().replace(R.id.fragmentContainerView2,fragment).commit();
                return true;
            }
        });
    }

}
